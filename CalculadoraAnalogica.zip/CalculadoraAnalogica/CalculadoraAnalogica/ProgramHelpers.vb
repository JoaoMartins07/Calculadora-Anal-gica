﻿Module ProgramHelpers

    Public resultadoEcra As Integer
End Module
