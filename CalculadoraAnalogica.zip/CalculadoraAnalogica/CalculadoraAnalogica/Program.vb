Imports System
Imports System.Security.Cryptography.X509Certificates

Module Program

    ' declara��o de variaveis a utilizar no Program
    Public resultadoEcra As Decimal
    Public opx As String

    Sub Main(args As String())

        Console.WriteLine("Escolha uma das seguintes op��es a executar: ")
        Console.WriteLine("SOMA - para somar ")
        Console.WriteLine("SUBTRAIR - para subtrair ")
        Console.WriteLine("DIVIDIR - para dividir ")
        Console.WriteLine("MULTIPLICAR - para multiplicar ")
        Console.WriteLine("A sua opera��o: ")

        opx = Console.ReadLine()

        If opx = "SOMA" Then
            ' vai somar
            funcaoSoma()
            Console.WriteLine(resultadoEcra)
        ElseIf opx = "SUBTRAIR" Then
            'vaisubtrair
            funcaoSubtrair()
            Console.WriteLine(resultadoEcra)
        ElseIf opx = "DIVIDIR" Then
            'vaiDividir
            funcaoDivide()
            Console.WriteLine(resultadoEcra)
        ElseIf opx = "MULTIPLICAR" Then
            'vaiMultiplicar
            funcaoMultiplica()
            Console.WriteLine(resultadoEcra)
        Else
            Console.WriteLine("Opera��o n�o encontrada")
        End If
    End Sub

    Sub funcaoSoma()
        Dim num1 As Integer
        Dim num2 As Integer

        Console.WriteLine("Escreva o 1 numero")
        num1 = Console.ReadLine()
        Console.WriteLine("Escreva o 2 numero")
        num2 = Console.ReadLine()
        resultadoEcra = num1 + num2
    End Sub

    Sub funcaoSubtrair()
        Dim num1 As Integer
        Dim num2 As Integer

        Console.WriteLine("Escreva o 1 numero")
        num1 = Console.ReadLine()
        Console.WriteLine("Escreva o 2 numero")
        num2 = Console.ReadLine()
        resultadoEcra = num1 - num2
    End Sub
    Sub funcaoMultiplica()
        Dim num1 As Integer
        Dim num2 As Integer

        Console.WriteLine("Escreva o 1 numero")
        num1 = Console.ReadLine()
        Console.WriteLine("Escreva o 2 numero")
        num2 = Console.ReadLine()
        resultadoEcra = num1 * num2
    End Sub

    Sub funcaoDivide()
        Dim num1 As Integer
        Dim num2 As Integer

        Console.WriteLine("Escreva o 1 numero")
        num1 = Console.ReadLine()
        Console.WriteLine("Escreva o 2 numero")
        num2 = Console.ReadLine()
        resultadoEcra = num1 / num2
    End Sub

End Module
